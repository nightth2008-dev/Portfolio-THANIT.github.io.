const nav = document.getElementById('mainNav');
const menuToggle = document.getElementById('menuToggle');
menuToggle.addEventListener('click', () => nav.classList.toggle('open'));
nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => nav.classList.remove('open')));

const progress = document.getElementById('progress');
window.addEventListener('scroll', () => {
  const max = document.documentElement.scrollHeight - window.innerHeight;
  progress.style.width = (max > 0 ? window.scrollY / max * 100 : 0) + '%';
});
document.getElementById('year').textContent = new Date().getFullYear();

// Click an image to view it larger.
const lightbox = document.getElementById('lightbox');
const lightboxImage = document.getElementById('lightboxImage');
document.querySelectorAll('.about-photo img, .feature-card img, .gallery-card img, .certificate-cover img').forEach(img => {
  img.style.cursor = 'zoom-in';
  img.addEventListener('click', () => {
    lightboxImage.src = img.src;
    lightbox.classList.add('open');
    lightbox.setAttribute('aria-hidden', 'false');
  });
});
function closeLightbox() {
  lightbox.classList.remove('open');
  lightbox.setAttribute('aria-hidden', 'true');
}
document.getElementById('closeLightbox').addEventListener('click', closeLightbox);
lightbox.addEventListener('click', e => { if (e.target === lightbox) closeLightbox(); });
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeLightbox(); });

// Built-in text editor: edits are saved in this browser on this device.
const editToggle = document.getElementById('editToggle');
const editable = [...document.querySelectorAll('[data-editable]')];
const toast = document.getElementById('editToast');
let editing = false;
const storageKey = 'portfolio-editable-content-v1';
function restoreText() {
  try {
    const saved = JSON.parse(localStorage.getItem(storageKey) || '[]');
    editable.forEach((el, i) => { if (typeof saved[i] === 'string') el.textContent = saved[i]; });
  } catch (e) {}
}
function saveText() {
  localStorage.setItem(storageKey, JSON.stringify(editable.map(el => el.textContent)));
}
restoreText();
editToggle.addEventListener('click', () => {
  editing = !editing;
  document.body.classList.toggle('editing', editing);
  editToggle.textContent = editing ? '✓ บันทึกข้อมูล' : '✎ แก้ไขข้อมูล';
  editable.forEach(el => {
    el.contentEditable = editing ? 'true' : 'false';
    el.spellcheck = false;
  });
  if (!editing) saveText();
  toast.textContent = editing ? 'โหมดแก้ไขเปิดอยู่ — คลิกข้อความเพื่อพิมพ์แก้ไข' : 'บันทึกข้อมูลไว้ในเบราว์เซอร์นี้แล้ว';
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 2600);
});
